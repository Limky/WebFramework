package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Customer;
import util.CustomerMap;

/**
 * Servlet implementation class DoLogin
 */
@WebServlet("/DoLogin")
public class DoLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String customerID = request.getParameter("customerID");
		String Password = request.getParameter("Password");
		
		//perform business logic. return & bean as a result
		CustomerMap service = new CustomerMap();
		Customer customer =service.findCustomer(customerID);
		
		
		
		String page=null;
		
		if(customer==null){
				
			request.setAttribute("badid", customerID);
			page="/jsps/error.jsp";
		}
		else{
			request.setAttribute("customer", customer);
			
			String getcustomerpassword = customer.getPassword();
			if(Password.equals(getcustomerpassword)){
			
				page="/jsps/form.jsp";
			
			}else{
			
			page="/jsps/passwordfail.jsp";
				
			}
			
	
		}

		RequestDispatcher dispatcher=request.getRequestDispatcher(page);
		dispatcher.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
